﻿using System;
class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese valor 1");
        int valor1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese valor 2");
        int valor2 = Convert.ToInt32(Console.ReadLine());

        /* operaciones aritméticas */

        Console.WriteLine(valor1 + " + " + valor2 + " = " + (valor1 + valor2));
        Console.WriteLine(valor1 + " - " + valor2 + " = " + (valor1 - valor2));
        Console.WriteLine(valor1 + " * " + valor2 + " = " + (valor1 * valor2));
        Console.WriteLine(valor1 + " / " + valor2 + " = " + (double)valor1 / valor2);

        Console.WriteLine(valor1 + " DIV " + valor2 + " = " + valor1 / valor2);
        Console.WriteLine(valor1 + " MOD " + valor2 + " = " + valor1 % valor2);

        /* operacion con boleana */

        if (valor1 > valor2)
        {
            Console.WriteLine("Es mayor el valor n1");
        }
        if (valor1 < valor2)
        {
            Console.WriteLine("Es mayor el valor n2");
        }
        if (valor1 == valor2)
        {
            Console.WriteLine("Los dos valores son iguales");
        }
        Console.ReadKey();
    }



}

