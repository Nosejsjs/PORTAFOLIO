﻿using System;
class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ejercicio 2");
        Console.WriteLine("ingrese el numero del dia");
        int numero = Convert.ToInt32(Console.ReadLine());

        if(numero < 0) 
        {
            Console.WriteLine("Error: El numero a ingresar debe estar contenido entre 1 y 7");
        }
        else if(numero > 7)
        {
            Console.WriteLine("Error: El numero a ingresar debe estar contenido entre 1 y 7");
        }

        switch (numero) 
        { 
        case 1: Console.WriteLine("el dia " + numero + " de la semana, es lunes");
                break;
        case 2: Console.WriteLine("el dia " + numero + " de la semana, es martes");
                break;
        case 3: Console.WriteLine("el dia " + numero + " de la semana, es miercoles");
                break;
        case 4: Console.WriteLine("el dia " + numero + " de la semana, es jueves");
                break;
        case 5: Console.WriteLine("el dia " + numero + " de la semana, es viernes");
                break;
        case 6: Console.WriteLine("el dia " + numero + " de la semana, es sabado");
                break;
        case 7: Console.WriteLine("el dia " + numero + " de la semana es domingo");
                break;
        default: Console.WriteLine("Error: El numero ingresado no pertenece a ningun dia de la semana");
                break;
        }
    }

}