﻿using System;
class program
{
    static void Main(String[] args)
    {
        Console.WriteLine("Ejercicio 1");
        Console.WriteLine("Ingrese numero ENTERO");
        int ENTERO = Convert.ToInt32(Console.ReadLine());

        if (ENTERO == 0)
        {
            Console.WriteLine(ENTERO + " es igual a 0");
        }
        else if (ENTERO < 0)
        {
            Console.WriteLine(ENTERO + " es negativo");
        }
        else if (ENTERO > 0)
        {
            Console.WriteLine(ENTERO + " es positivo");
        }
    }
}
